# Heatwave Watch — Streamlit App

Heatwave Watch is a Streamlit dashboard for exploring maximum-temperature observations by region and date. It shows summary metrics, a temperature trend, a temperature distribution, a region comparison, a filtered data table, and a CSV download.

## Project files

- `app.py` — Streamlit dashboard.
- `heatwave_data.csv` — small sample dataset so the app runs immediately. Replace it with your real dataset before publishing.
- `requirements.txt` — Python packages needed to run the app.
- `region_bst.c` — optional C example of a binary-search-tree date-range query, kept as a companion algorithm file. The Streamlit app currently uses Pandas for filtering and does not compile or call this C file.
- `.gitignore` — excludes common local environment and cache files.

## CSV format

Your dataset must have these columns:

| Column | Meaning | Example |
|---|---|---|
| `region` | Region name | `North` |
| `date` | Observation date | `2026-05-01` |
| `lat` | Latitude | `19.0760` |
| `lon` | Longitude | `72.8777` |
| `tmax` | Maximum temperature in °C | `41.2` |

Column names should match exactly. Extra columns are allowed. The app converts dates and numeric fields, then drops rows with missing/invalid required values.

**Important:** the included CSV is sample data only. Use your own authentic dataset for real analysis and public deployment.

## Run locally on Windows

1. Install Python 3.10 or newer from https://www.python.org/downloads/ (enable the option to add Python to PATH during installation).
2. Extract this ZIP file.
3. Open the extracted `heatwave_watch_streamlit` folder in VS Code.
4. Open **Terminal → New Terminal**.
5. Create a virtual environment:

   ```powershell
   py -m venv .venv
   ```

6. Activate it:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, run this in the same terminal and try activation again:

   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy RemoteSigned
   .\.venv\Scripts\Activate.ps1
   ```

7. Install dependencies:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

8. Start the app:

   ```powershell
   streamlit run app.py
   ```

9. Streamlit should open a browser tab. If it does not, copy the local URL printed in the terminal (usually `http://localhost:8501`) into Chrome.

Stop the app with `Ctrl+C` in the terminal.

## Deploy free on Streamlit Community Cloud

### Before deploying

1. Create or sign in to a GitHub account: https://github.com/
2. Create a **new public GitHub repository**, for example `heatwave-watch`.
3. Upload/push the files from this folder to the repository root:
   - `app.py`
   - `requirements.txt`
   - `heatwave_data.csv` (or your appropriately sized public dataset)
   - optionally `region_bst.c`, `.gitignore`, and this README
4. Check that `app.py` and `requirements.txt` are at the top level of the repository, not inside an extra nested folder.

### Publish

1. Go to https://share.streamlit.io/ and sign in with GitHub.
2. Choose **Create app** (or **Deploy an app**).
3. Select your repository, branch (usually `main`), and main file path `app.py`.
4. Click **Deploy**.
5. Wait for the build to finish. Streamlit will install packages from `requirements.txt`.
6. Open the generated app URL and test the filters, charts, and CSV download.

Streamlit Cloud screens can change slightly; follow the current prompts shown in your account.

## Updating the dataset

Replace `heatwave_data.csv` with your real CSV, keeping the required column names. Commit and push the change to GitHub; Streamlit Cloud will redeploy the app. You can also upload a CSV from the sidebar while using the app.

## Common issues

- **`FileNotFoundError: heatwave_data.csv`** — keep the CSV in the same folder as `app.py` and commit it to GitHub.
- **`ModuleNotFoundError`** — run `pip install -r requirements.txt` in the activated virtual environment.
- **`streamlit` is not recognized** — try `python -m streamlit run app.py`.
- **No observations found** — adjust the selected region/date range or check that the CSV values are valid.
- **CSV columns error** — verify exact column names: `region`, `date`, `lat`, `lon`, `tmax`.
- **GitHub upload too large / private data** — do not publish confidential or restricted data in a public repository. Use an appropriately secured hosting option if the data must remain private.

## About the C file

`region_bst.c` contains a binary search tree with range-query functions. It is included as a companion algorithm file only; the Python dashboard does not currently use it. The C program expects a calling program to invoke `addReading()` and `queryRegion()`, so it is not a standalone interactive application as supplied.
